/* CS 314 STUDENTS: FILL IN THIS HEADER.
 *
 * Student information for assignment:
 *
 *  On my honor, <NAME>, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID:
 *  email address:
 *  TA name:
 *  Number of slip days I am using:
 */

import java.util.ArrayList;
import java.util.List;

/**
 * Shell for a binary search tree class.
 * 
 * @author scottm
 * @param <E> The data type of the elements of this BinarySearchTree. Must
 *            implement Comparable or inherit from a class that implements
 *            Comparable.
 *
 */
public class BinarySearchTree<E extends Comparable<? super E>> {

	private BSTNode<E> root;
	private int size;

	//adapted from lecture
	public boolean add(E value) {
		//calls the recursive method
		int oldSize = size;
		root = addHelp(root, value);
		return oldSize != size;
	}
	//adapted from lecture
	private BinarySearchTree.BSTNode<E> addHelp(BSTNode<E> node, E value) {
		//find the location to add the object by comparing the data in the nodes and finding where the on=bject 
		//would be in between them
		if (node == null) {
			size++;
			return new BSTNode<E>(value);
		}
		int dir = value.compareTo(node.data);
		if (dir < 0) {
			node.left = addHelp(node.left, value);
		} else if (dir > 0) {
			node.right = addHelp(node.right, value);
		}
		return node;
	}

	//adapted from lecture
	public boolean remove(E value) { //||
		int oldSize = size;
		root = removeHelp(root, value);
		return size == oldSize - 1;
	}
	//adapted from lecture
	private BSTNode<E> removeHelp(BSTNode<E> node, E value) {
		if (node == null) {
			return node;
		}
		//goes through until the calue is found
		int diff = value.compareTo(node.data);
		if (diff < 0) {
			node.left = removeHelp(node.left, value);
		} else if (diff > 0) {
			node.right = removeHelp(node.right, value);
		} else {
			//when found, it rearranges the tree by moving the max of the branch to the top node
			//after the removal and adjusts size
			size--;
			if (node.left == null && node.right == null) {
				return null;
			} else if (node.left == null) {
				return node.right;
			} else if (node.right == null) {
				return node.left;
			} else {
				E maxLeftSubtree = removeMax(node.left); // private method
				node.data = maxLeftSubtree;
				node.left = removeHelp(node.left, maxLeftSubtree);
				size++;
			}
		}
		return node;
	}
	
	//adapted from lecture
	private E removeMax(BSTNode<E> n) {
		//gets the last on the right of the branch
		while (n.right != null) {
			n = n.right;
		}
		return n.data;
	}

	public boolean isPresent(E value) { 
		//checks to see if a certain value is present
		BSTNode<E> node = root;
		while (node != null) {
			//itertaively goes through until the value is found
			int diff = value.compareTo(node.data);
			if (diff < 0) {
				node = node.left;
			} else if (diff > 0) {
				node = node.right;
			} else {
				return true;
			}
		}
		return false;
	}
	public int size() { 
		return size;
	}
	//adapted from lecture
	public int height() { 
		return htHelp(root);
	}
	//adapted from lecture
	private int htHelp(BSTNode<E> node) {
		//calculates the height of the tree by going down the branch with the maximum values
		if (node == null) {
			return -1;
		} else {
			return 1 + Math.max(htHelp(node.left), htHelp(node.right));
		}
	}

	/**
	 * Return a list of all the elements in this Binary Search Tree. <br>
	 * pre: none<br>
	 * post: return a List object with all data from the tree in ascending order. If
	 * the tree is empty return an empty List
	 * 
	 * @return a List object with all data from the tree in sorted order if the tree
	 *         is empty return an empty List
	 */
	public List<E> getAll() {
		//returns all the data in order
		List<E> result = new ArrayList<>();
		if (this.root == null) {
			return result;
		}
		BSTNode<E> node = root;
		inOrder(node, result);
		return result;
	}

	private void inOrder(BSTNode<E> node, List<E> result) {
		//does an in order traversal
		if (node == null) {
			return;
		}
		inOrder(node.left, result);
		result.add(node.data);
		inOrder(node.right, result);
	}

	/**
	 * return the maximum value in this binary search tree. <br>
	 * pre: <tt>size()</tt> > 0<br>
	 * post: return the largest value in this Binary Search Tree
	 * 
	 * @return the maximum value in this tree
	 */
	//adapted from lecture
	public E max() { 
		//goes all the way to the data in the right end and returns the data in
		//that node
		if (size <= 0) {
			throw new IllegalStateException("preconditions not met");
		}

		if (size == 1) {
			return root.data;
		}
		BSTNode<E> node = root;
		while (node.right != null) {
			node = node.right;
		}
		return node.data;
	}

	/**
	 * return the minimum value in this binary search tree. <br>
	 * pre: <tt>size()</tt> > 0<br>
	 * post: return the smallest value in this Binary Search Tree
	 * 
	 * @return the minimum value in this tree
	 */
	//adapted from lecture
	public E min() { //
		//goes all the way to the left end and returns the data in 
		//that node
		if (size <= 0) {
			throw new IllegalStateException("preconditions not met");
		}
		if (size == 1) {
			return root.data;
		}
		BSTNode<E> node = root;
		while (node.left != null) {
			node = node.left;
		}
		return node.data;
	}

	/**
	 * An add method that implements the add algorithm iteratively instead of
	 * recursively. <br>
	 * pre: data != null <br>
	 * post: if data is not present add it to the tree, otherwise do nothing.
	 * 
	 * @param data the item to be added to this tree
	 * @return true if data was not present before this call to add, false
	 *         otherwise.
	 */
	public boolean iterativeAdd(E data) { //||
		if (data == null) {
			throw new IllegalStateException("preconditions not met");
		}
		int oldSize = size;
		BSTNode<E> node = root;
		if (oldSize == 0) {
			root.data = data;
			return true;
		}
		// check's to see if the data is already present
		int last = 0;
		boolean end = true;
		//keeps going if it isnt
		while (node != null && end) {
			if (node.data == data) {
				return false;
			}
			int dir = data.compareTo(node.data);
			last = dir;
			if (dir < 0) {
				//compares the data in the nodes and sees which direction to move
				if (node.left != null) {
					node = node.left;
				} else {
					end = false;
				}
			} else if (dir > 0) {
				if (node.right != null) {
					node = node.right;
				} else {
					end = false;
				}
			}
		}
		// in the case that the node does return
		size++;
		if (last < 0) {
			node.left = new BSTNode<>(data);
		} else if (last > 0) {
			node.right = new BSTNode<>(data);
		}
		return size() == oldSize + 1;
	}

	/**
	 * Return the "kth" element in this Binary Search Tree. If kth = 0 the smallest
	 * value (minimum) is returned. If kth = 1 the second smallest value is
	 * returned, and so forth. <br>
	 * pre: 0 <= kth < size()
	 * 
	 * @param kth indicates the rank of the element to get
	 * @return the kth value in this Binary Search Tree
	 */
	public E get(int kth) { 
		//calls the recursive method
		if (kth < 0 || kth >= size()) {
			throw new IllegalStateException("preconditions not met");
		}
		int[] tracker = new int[1];
		BSTNode<E> node = root;
		node = getOrder(node, kth, tracker);
		return node.data;
	}

	private BSTNode<E> getOrder(BSTNode<E> node, int kth, int[] tracker) {
		//does an in order traversal until a certain number of times 
		if (node == null) {
			return null;
		}
		BSTNode<E> temp = getOrder(node.left, kth, tracker);
		if (temp != null) {
			return temp;
		}
		if (tracker[0] == kth) {
			return node;
		}
		tracker[0]++;
		temp = getOrder(node.right, kth, tracker);
		return temp;
	}

	public List<E> getAllLessThan(E value) { 
		//calls the recursive method
		if (value == null) {
			throw new IllegalStateException("preconditions not met");
		}
		List<E> result = new ArrayList<E>();
		lessOrder(root, result, value);
		return result;
	}

	private void lessOrder(BSTNode<E> node, List<E> result, E value) {
		//recursive method checks everything on the left side of the tree
		//and gets all the way to the bottom, and then starts traversing
		//through the right components of the branches tghat are applicable
		if (node == null) {
			return;
		}
		if (value.compareTo(node.data) > 0) {
			inOrder(node.left, result);
			result.add(node.data);
			lessOrder(node.right, result, value);
		} else {
			lessOrder(node.left, result, value);
		}

	}
	public List<E> getAllGreaterThan(E value) { 
		//gets all the values greater than a certain value
		//and adds it to a list
		if (value == null) {
			throw new IllegalStateException("preconditions not met");
		}
		List<E> result = new ArrayList<E>();
		greatOrder(value, root, result);
		return result;
	}

	private void greatOrder(E value, BSTNode<E> node, List<E> result) {
		//recursive method compares all the values on the left side and adds them, and 
		//then does an in order traversal of the right side nodes
		if (node == null) {
			return;
		}
		if (value.compareTo(node.data) < 0) {
			greatOrder(value, node.left, result);
			result.add(node.data);
			inOrder(node.right, result);
		} else {
			greatOrder(value, node.right, result);
		}
	}

	
	public int numNodesAtDepth(int d) {
		// calculates the number of nodes at a certain depth
		//using exponents
		if(d <= 0) {
			return 0;
		}
		return (int) Math.pow(2, d);
	}

	
	public void printTree() {
		printTree(root, "");
	}

	private void printTree(BSTNode<E> n, String spaces) {
		if (n != null) {
			printTree(n.getRight(), spaces + "  ");
			System.out.println(spaces + n.getData());
			printTree(n.getLeft(), spaces + "  ");
		}
	}

	private static class BSTNode<E extends Comparable<? super E>> {
		private E data;
		private BSTNode<E> left;
		private BSTNode<E> right;

		public BSTNode() {
			this(null);
		}

		public BSTNode(E initValue) {
			this(null, initValue, null);
		}

		public BSTNode(BSTNode<E> initLeft, E initValue, BSTNode<E> initRight) {
			data = initValue;
			left = initLeft;
			right = initRight;
		}

		public E getData() {
			return data;
		}

		public BSTNode<E> getLeft() {
			return left;
		}

		public BSTNode<E> getRight() {
			return right;
		}

		public void setData(E theNewValue) {
			data = theNewValue;
		}

		public void setLeft(BSTNode<E> theNewLeft) {
			left = theNewLeft;
		}

		public void setRight(BSTNode<E> theNewRight) {
			right = theNewRight;
		}
	}
}