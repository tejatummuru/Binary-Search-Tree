/* CS 314 STUDENTS: FILL IN THIS HEADER.
 *
 * Student information for assignment:
 *
 *  On my honor, <NAME>, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID:
 *  email address:
 *  TA name:
 *  Number of slip days I am using:
 *  
 *  Experiment results:
 *  time for 1000 random objects: elapsed time: 1.837E-4 seconds. round: 0
height after first 1000: 20 round: 0
size after 1000: 1000 round: 0
time for 1000 random objects: elapsed time: 1.871E-4 seconds. round: 1
height after first 1000: 21 round: 1
size after 1000: 2000 round: 1
time for 1000 random objects: elapsed time: 1.987E-4 seconds. round: 2
height after first 1000: 25 round: 2
size after 1000: 3000 round: 2
time for 1000 random objects: elapsed time: 2.042E-4 seconds. round: 3
height after first 1000: 25 round: 3
size after 1000: 4000 round: 3
time for 1000 random objects: elapsed time: 2.171E-4 seconds. round: 4
height after first 1000: 25 round: 4
size after 1000: 5000 round: 4
time for 1000 random objects: elapsed time: 2.215E-4 seconds. round: 5
height after first 1000: 26 round: 5
size after 1000: 6000 round: 5
time for 1000 random objects: elapsed time: 2.237E-4 seconds. round: 6
height after first 1000: 27 round: 6
size after 1000: 7000 round: 6
time for 1000 random objects: elapsed time: 2.278E-4 seconds. round: 7
height after first 1000: 28 round: 7
size after 1000: 8000 round: 7
time for 1000 random objects: elapsed time: 2.294E-4 seconds. round: 8
height after first 1000: 29 round: 8
size after 1000: 9000 round: 8
time for 1000 random objects: elapsed time: 2.398E-4 seconds. round: 9
height after first 1000: 29 round: 9
size after 1000: 10000 round: 9
avg time: 2.1329999999999998E-4 avg height: 25.5 avg size: 5500.0
time for 2000 random objects: elapsed time: 4.207E-4 seconds.
height after first 2000: 23
size after 2000: 2000
time for 4000 random objects: elapsed time: 7.066E-4 seconds.
height after first 4000: 24
size after 4000: 4000
time for 8000 random objects: elapsed time: 0.0016311 seconds.
height after first 8000: 27
size after 8000: 8000
time for 16000 random objects: elapsed time: 0.0034576 seconds.
height after first 16000: 35
size after 16000: 16000
time for 32000 random objects: elapsed time: 0.0083516 seconds.
height after first 32000: 34
size after 32000: 32000
time for 64000 random objects: elapsed time: 0.0167099 seconds.
height after first 64000: 39
size after 64000: 63999
time for 128000 random objects: elapsed time: 0.0394008 seconds.
height after first 128000: 43
size after 128000: 127995
time for 256000 random objects: elapsed time: 0.1175632 seconds.
height after first 256000: 44
size after 256000: 255993
time for 512000 random objects: elapsed time: 0.2924809 seconds.
height after first 512000: 49
size after 512000: 511971
time for 1024000 random objects: elapsed time: 0.6561003 seconds.
height after first 1024000: 55
size after 1024000: 1023883
time for 1000 random objects: elapsed time: 0.0014209 seconds. round: 0
size after 1000: 1000 round: 0
time for 1000 random objects: elapsed time: 8.876E-4 seconds. round: 1
size after 1000: 2000 round: 1
time for 1000 random objects: elapsed time: 4.344E-4 seconds. round: 2
size after 1000: 3000 round: 2
time for 1000 random objects: elapsed time: 3.929E-4 seconds. round: 3
size after 1000: 4000 round: 3
time for 1000 random objects: elapsed time: 3.408E-4 seconds. round: 4
size after 1000: 5000 round: 4
time for 1000 random objects: elapsed time: 5.551E-4 seconds. round: 5
size after 1000: 6000 round: 5
time for 1000 random objects: elapsed time: 4.909E-4 seconds. round: 6
size after 1000: 7000 round: 6
time for 1000 random objects: elapsed time: 4.112E-4 seconds. round: 7
size after 1000: 8000 round: 7
time for 1000 random objects: elapsed time: 4.204E-4 seconds. round: 8
size after 1000: 9000 round: 8
time for 1000 random objects: elapsed time: 3.884E-4 seconds. round: 9
size after 1000: 10000 round: 9
avg time: 5.742599999999999E-4
time for 2000 random objects: elapsed time: 5.714E-4 seconds.
size after 2000: 2000
time for 4000 random objects: elapsed time: 0.0011283 seconds.
size after 4000: 4000
time for 8000 random objects: elapsed time: 0.0023809 seconds.
size after 8000: 8000
time for 16000 random objects: elapsed time: 0.0063766 seconds.
size after 16000: 16000
time for 32000 random objects: elapsed time: 0.0122983 seconds.
size after 32000: 32000
time for 64000 random objects: elapsed time: 0.0276482 seconds.
size after 64000: 64000
experiment 2 height: 999 round: 0
experiment 2 height: 999 round: 1
experiment 2 height: 999 round: 2
experiment 2 height: 999 round: 3
experiment 2 height: 999 round: 4
experiment 2 height: 999 round: 5
experiment 2 height: 999 round: 6
experiment 2 height: 999 round: 7
experiment 2 height: 999 round: 8
experiment 2 height: 999 round: 9
 avg height: exp2 999.0 avg size: exp2 1000.0
experiment 2 height: 999
experiment 2 height: 999
experiment 2 height: 999
experiment 2 height: 999
experiment 2 height: 999
experiment 2 height: 999
exp2 tree ver time: 8.378E-4experiment 2 height:  round: 0
exp2 tree ver time: 0.0011599experiment 2 height:  round: 1
exp2 tree ver time: 0.0013853experiment 2 height:  round: 2
exp2 tree ver time: 0.001597experiment 2 height:  round: 3
exp2 tree ver time: 0.0018306experiment 2 height:  round: 4
exp2 tree ver time: 0.0020435experiment 2 height:  round: 5
exp2 tree ver time: 0.0022391experiment 2 height:  round: 6
exp2 tree ver time: 0.0024356experiment 2 height:  round: 7
exp2 tree ver time: 0.0026264experiment 2 height:  round: 8
exp2 tree ver time: 0.0028193experiment 2 height:  round: 9
avg time: 0.0018974500000000002
experiment 2 time: 2.365E-4
experiment 2 time: 2.221E-4
experiment 2 time: 2.182E-4
experiment 2 time: 2.213E-4
experiment 2 time: 2.164E-4
experiment 2 time: 2.223E-4

Answers to Questions:
For each value of N what is the minimum possible tree height, assuming N unique values are inserted into the tree?
height after first 1000: 20
height after first 2000: 23
height after first 4000: 24
height after first 8000: 27
height after first 16000: 35
height after first 32000: 34
height after first 64000: 39
height after first 128000: 43
height after first 256000: 44
height after first 512000: 49
height after first 1024000: 55

How do these times compare to the times it took for you BinarySearchTree class when inserting integers in sorted order? 
What do you think is the cause for these differences?

The times were really similar, but as the numbers increased the times for the binary search tree were slightly higher
I believe the main differentiator is the left and right node system, which causes a bit more word to 
traverse the internal storage system to get the output as we need both the left and right nodes as well. 
Additionally TreeSet can be accessed and traversed in both ascending or descending orders, and 
the performance of ascending operations and views is likely to be faster than that of descending ones thus giving it
more options of traversion and more options and thus a time variation. 
 */


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;

/**
 * Some test cases for CS314 Binary Search Tree assignment.
 *
 */
public class BSTTester {

    /**
     * The main method runs the tests.
     * @param args Not used
     */
    public static void main(String[] args) {
        BinarySearchTree<String> t = new BinarySearchTree<>();

        //tests add
        t.add("gaslight");
        //tests add
        t.add("gatekeep");
        //tests getAll
        List<String> test = new ArrayList<>();
        test.add("gaslight");
        test.add("gatekeep");
        if(t.getAll().equals(test) && t.size() == 2 && t.height() == 1) {
        	System.out.println("passed test 1");
        }else {
        	System.out.println("failed test 1");
        }
        //tests itertaive add
        t.iterativeAdd("girlboss");
        t.iterativeAdd("removeMarker");        
        test.add("girlboss");
        //tests itertive add
        t.iterativeAdd("my anthem");
        t.remove("removeMarker");
        t.remove("my anthem");
        //tests getAll
        if(t.getAll().equals(test) && t.size() == 3 && t.height() == 1) {
        	System.out.println("passed test 2");
        }else {
        	System.out.println("failed test 2");
        }
        //tests isPresent
        if(t.isPresent("girlboss") == true && t.max() == "girlboss" && t.min() == "gaslight") {
        	System.out.println("passed test 3");
        }else {
        	System.out.println("failed test 3");
        }
        t.add("zoo wee mama");
        //tests isPresent
        if(t.isPresent("removeMarker") == false && t.max() == "zoo wee mama" && t.min() == "gaslight") {
        	System.out.println("passed test 4");
        }else {
        	System.out.println("failed test 4");
        }
        
        if(t.get(0) == "gaslight" && t.get(1) == "gatekeep") {
        	System.out.println("passed test 5");
        }else {
        	System.out.println("failed test 5");        
        }
        List<String> test2 = new ArrayList<>();
        List<String> test3 = new ArrayList<>();
        if(t.getAllGreaterThan("zzzzz").equals(test3) && t.getAllLessThan("aaaaaaa").equals(test3)) {
        	System.out.println("passed test 6");
        }else {
        	System.out.println("failed test 6");
        }
        test2.add("gatekeep");
        test2.add("girlboss");
        if(t.getAllGreaterThan("gasilght").equals(test2)) {
        	System.out.println("passed test 7");
        }else {
        	System.out.println("failed test 7");
        }
        test2.clear();
        test2.add("gaslight");
        test2.add("gatekeep");
        if(t.getAllLessThan("girlboss").equals(test2)) {
        	System.out.println("passed test 8");
        }else {
        	System.out.println("failed test 8");
        }
        
        if(t.numNodesAtDepth(0) == 0 && t.numNodesAtDepth(1) == 2) {
        	System.out.println("passed test 9");
        }else {
        	System.out.println("failed test 9");
        }
        //experiment tests
        experiments();
        treeVer();
        experiment2();
        treeVerExp2();
        
    }

    private static void showTestResults(boolean passed, int testNum) {
        if (passed) {
            System.out.println("Test " + testNum + " passed.");
        } else {
            System.out.println("TEST " + testNum + " FAILED.");
        }
    }
    
    private static void experiments() {
    	//insert 1000 objects
    	int n = 1000;
    	Random r = new Random();
        BinarySearchTree<Integer> t = new BinarySearchTree<>();
        double totalTime = 0.0;
        double totalHeight = 0.0;
        double totalSize = 0.0;
        for(int j = 0; j < 10; j++) {       
	        Stopwatch s = new Stopwatch();
	        s.start();
	    	for(int i = 0; i < n; i++) {
	    		Integer addition = new Integer(r.nextInt());
	    	    t.add(addition); 
	    		}
	    		s.stop();
	    		totalTime+=s.time();
	    		totalHeight+=t.height();
	    		totalSize+=t.size();
	    		System.out.println("time for 1000 random objects: " + s.toString() + " round: " + j);
	        	System.out.println("height after first 1000: " + t.height() + " round: " + j);
	        	System.out.println("size after 1000: " + t.size() + " round: " + j);
        }
    	System.out.println("avg time: " + totalTime/10 + " avg height: " + totalHeight/10 + " avg size: " + totalSize/10);
    	iterationsExp(2000);
    	iterationsExp(4000);
    	iterationsExp(8000);
    	iterationsExp(16000);
    	iterationsExp(32000);
    	iterationsExp(64000);
    	iterationsExp(128000);
    	iterationsExp(256000);
    	iterationsExp(512000);
    	iterationsExp(1024000);
    }
    
    private static void iterationsExp(int n) {
    	Random r = new Random();
        BinarySearchTree<Integer> t = new BinarySearchTree<>();
    	Stopwatch s = new Stopwatch();
        s.start();
    	for(int i = 0; i < n; i++) {
    		Integer addition = new Integer(r.nextInt());
    	    t.add(addition); 
    		}
    		s.stop();
    		
    		System.out.println("time for " + n + " random objects: " + s.toString() );
        	System.out.println("height after first " + n + ": " + t.height() );
        	System.out.println("size after " + n + ": " + t.size());
    }
    
    private static void treeVer() {
    	int n = 1000;
    	Random r = new Random();
    	TreeSet<Integer> t = new TreeSet<>();
        double totalTime = 0.0;
        double totalSize = 0.0;
        for(int j = 0; j < 10; j++) {       
	        Stopwatch s = new Stopwatch();
	        s.start();
	    	for(int i = 0; i < n; i++) {
	    		Integer addition = new Integer(r.nextInt());
	    	    t.add(addition); 
	    		}
	    		s.stop();
	    		totalTime+=s.time();
//	    		totalHeight+=t.height();
	    		totalSize+=t.size();
	    		System.out.println("time for 1000 random objects: " + s.toString() + " round: " + j);
//	        	System.out.println("height after first 1000: " + t.height() + " round: " + j);
	        	System.out.println("size after 1000: " + t.size() + " round: " + j);
        }
    	System.out.println("avg time: " + totalTime/10 );
        treeExp(2000);
        treeExp(4000);
        treeExp(8000);
        treeExp(16000);
        treeExp(32000);
        treeExp(64000);
//        treeExp(128000);
//        treeExp(256000);
//        treeExp(512000);
//        treeExp(1024000);
    }
    private static void treeExp(int n) {
    	Random r = new Random();
    	TreeSet<Integer> t = new TreeSet<>();
    	Stopwatch s = new Stopwatch();
        s.start();
    	for(int i = 0; i < n; i++) {
    		Integer addition = new Integer(r.nextInt());
    	    t.add(addition); 
    		}
    		s.stop();
    		
    		System.out.println("time for " + n + " random objects: " + s.toString() );
//        	System.out.println("height after first " + n + ": " + t.height() );
        	System.out.println("size after " + n + ": " + t.size());
    }
    
    private static void experiment2() {
    	ArrayList<Integer> ints = new ArrayList<>();
    	for(int i = 0; i < 1000; i++) {
    		ints.add(i);
//    		ints.add(i , new Integer(i));
    	}
    	double totalHeight = 0.0;
        double totalSize = 0.0;
        BinarySearchTree<Integer> t = new BinarySearchTree<>();
        for(int i = 0; i < 10; i++) {
        	for(Integer num : ints) {
                t.add(num);
            }
        	totalHeight+=t.height();
        	totalSize+=t.size();
            System.out.println("experiment 2 height: " + t.height() + " round: " + i);
        }
    	System.out.println(" avg height: exp2 " + totalHeight/10 + " avg size: exp2 " + totalSize/10);
    	secIt(2000);
        secIt(4000);
        secIt(8000);
        secIt(16000);
        secIt(32000);
        secIt(64000);
    }
    
    public static void secIt(int n) {
    	ArrayList<Integer> ints = new ArrayList<>();
    	for(int i = 0; i < 1000; i++) {
    		ints.add(i);
//    		ints.add(i , new Integer(i));
    	}
        BinarySearchTree<Integer> t = new BinarySearchTree<>();
       
        	for(Integer num : ints) {
                t.add(num);
            }
            System.out.println("experiment 2 height: " + t.height());
            
//            secIt(128000);
//            secIt(256000);
//            secIt(512000);
//            secIt(1024000);
    }
    public static void treeVerExp2() {
    	ArrayList<Integer> ints = new ArrayList<>();
    	for(int i = 0; i < 1000; i++) {
    		ints.add(i);
//    		ints.add(i , new Integer(i));
    	}
        double totalSize = 0.0;
        double totalTime = 0.0;
        TreeSet<Integer> t = new TreeSet<>();
        Stopwatch s = new Stopwatch();
        s.start();
        for(int i = 0; i < 10; i++) {
        	for(Integer num : ints) {
                t.add(num);
            }
        	s.stop();
        	totalSize+=t.size();
        	totalTime+=s.time();
            System.out.println("exp2 tree ver time: " + s.time() + "experiment 2 height: " +  " round: " + i);
            
        }
    	System.out.println( "avg time: " + totalTime/10);
    	treesecIt(2000);
        treesecIt(4000);
        treesecIt(8000);
        treesecIt(16000);
        treesecIt(32000);
        treesecIt(64000);
    }
    public static void treesecIt(int n) {
    	ArrayList<Integer> ints = new ArrayList<>();
    	for(int i = 0; i < 1000; i++) {
    		ints.add(i);
//    		ints.add(i , new Integer(i));
    	}
    	TreeSet<Integer> t = new TreeSet<>();
    	Stopwatch s = new Stopwatch();
    	s.start();
        	for(Integer num : ints) {
                t.add(num);
            }
        	s.stop();
            System.out.println("experiment 2 time: " + s.time());

    }
}